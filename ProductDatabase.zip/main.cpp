#include "product.h"

int main() {
    Menu::run();
    return 0;
}
    
